package com.example.soundstation.modelo

public final data class Cancion(
    val id: String = "",
    val titulo: String = "",
    val artista: String = "",
    val url: String = "",
)


